from django.apps import AppConfig


class ClassifiedsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "classifieds"
    verbose_name = "Classifieds"
